#!/bin/bash
export WORLD="world21"
export EE4308_TASK="proj2"
