export TURTLE_X=-0.9
export TURTLE_Y=0.9
export TURTLE_GOALS="0.8,0.8   0.7,-0.8   -0.8,0.2"
export TURTLE_MIN_X=-8.0
export TURTLE_MIN_Y=-13.0
export TURTLE_MAX_X=7.0
export TURTLE_MAX_Y=3.0
