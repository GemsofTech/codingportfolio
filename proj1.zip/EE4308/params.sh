#!/bin/bash
export WORLD="world22proj1"
export EE4308_TASK="proj1"